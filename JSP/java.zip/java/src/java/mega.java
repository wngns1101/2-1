package java;

public class mega {

	}
}
