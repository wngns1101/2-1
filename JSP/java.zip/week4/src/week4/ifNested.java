package week4;

public class ifNested {
	public static void main(String[] args) {
		int score = (int) (Math.random()*100);
		String grade;
		
		if(score >= 90) {
			if (score > 96)
				grade = "A+";
		} else if(score > 93) {
			grade = "A";
		} else {
			grade = "B+";
		
	}
	}
}
// ���� �Ͻ� �ٽ� 36��