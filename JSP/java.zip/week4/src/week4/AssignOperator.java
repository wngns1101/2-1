package week4;

public class AssignOperator {
	public static void main(String[] args) {
		int result = 10;
		
		result += 10;
		System.out.println("result = " + result);
	
		result -= 3;
		System.out.println("result = " + result);
		
		result *= 5;
		System.out.println("result = " + result);
		
		result /= 6;
		System.out.println("result = " + result);
		
		result %= 10;
		System.out.println("result = " + result);
	}
}
