package week4;

public class TwoOperand2 {
	public static void main(String[] args) {
		int x = 15;
		double y = 0.0;
		
		double z1 = x / y;
		double z2 = x % y;
		
		System.out.println("z1 = " + z1);
		System.out.println("z2 = " + z2);
	}
}
