package midterm;

public class IfDice {
	public static void main(String[] args) {
		double num = Math.random();
		System.out.println(num);
		int number = (int) ((Math.random()*6)+1);
		System.out.println(number);
	}
	
}
