package week3;

public class PromotionType {
	public static void main(String[] args) {
		byte bValue = 25;
		int iValue = bValue;
		System.out.println(iValue);
	
		char cValue = '��';
		iValue = cValue;
		System.out.println(iValue);
		
		iValue = 375;
		long lValue = iValue;
		System.out.println(lValue);
		
		double dValue = iValue;
		System.out.println(dValue);
	}
}
