package week7;

public class Pet {
	String type;
	int age;
	int leg;
	
	public Pet(String type, int age){
		this.type = type;
		this.age = age;
	}
	
}
