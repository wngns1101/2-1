package week7;

public class Circle {
	int radius;
	String name;
	
	public Circle() {
		radius = 1;
	}
	
	public Circle(int radius, String name) {
		this.radius = radius;
		this.name = name;
	}
	
}
